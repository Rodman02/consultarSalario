﻿namespace calcularSalario
{
    public class Empleado
    {
        private string nombre;
        private string cedula;
        private decimal asignacionDia;

        public string Nombre { get; set; }
        public string Cedula { get; set; }
        public decimal AsignacionDia { get; set; }
    }
}
