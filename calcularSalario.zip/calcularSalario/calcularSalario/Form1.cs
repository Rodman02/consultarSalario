﻿using System;
using System.Windows.Forms;

namespace calcularSalario
{
    public partial class Form1 : Form
    {
        Empleado myEmpleado = new Empleado();
        Nomina myNomina = new Nomina();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_registro_Click(object sender, EventArgs e)
        {
            //ingrese un dato
            if(txt_nombre.Text == "")
            {
                error1.SetError(txt_nombre, "Debe ingresar un nombre");
                txt_nombre.Focus();
                return;
            }
            error1.SetError(txt_nombre, "");

            //validar agregar datos númericos
            decimal diastrabajados;
            if(!Decimal.TryParse(txt_diastrabajados.Text, out diastrabajados))
            {
                error1.SetError(txt_diastrabajados, "Debe ingresar un número");
                txt_nombre.Focus();
                return;
            }
            error1.SetError(txt_diastrabajados, "");

            myEmpleado.Nombre = txt_nombre.Text;
            myEmpleado.Cedula = txt_cedula.Text;
            myEmpleado.AsignacionDia = Convert.ToDecimal(txt_salario.Text);
            myNomina.DiasLaborados = Convert.ToInt32(txt_diastrabajados.Text);
            MessageBox.Show("Todo se ha registrado correctamente.");
        }

        private void btn_calcularsalario_Click(object sender, EventArgs e)
        {
            txt_total.Text = myNomina.CalcularNomina(Convert.ToInt32(myNomina.DiasLaborados), 
                Convert.ToDecimal(myEmpleado.AsignacionDia)).ToString();

        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            txt_nombre.Clear();
            txt_cedula.Clear();
            txt_salario.Clear();
            txt_diastrabajados.Clear();
            txt_total.Clear();
        }
    }
}
