﻿namespace calcularSalario
{
    public class Nomina
    {
        private int diasLaborados;

        public int DiasLaborados { get; set; }

        //calcular nomina
        public decimal CalcularNomina (int diasLab, decimal valorDia)
        {
            decimal totalSalario = diasLab * valorDia;
            return totalSalario;
        }
    }
}
